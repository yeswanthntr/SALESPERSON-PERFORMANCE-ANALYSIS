use sales;
select * from superstore;
-- finding the sales of sales person
select salesperson,sum(sales) as total_sales from superstore group by salesperson;
-- finding the profit of salesperson
select salesperson,sum(profit) as toatl_profit from superstore group by salesperson;
-- finding the order of salesperson
select salesperson,count('order id') as no_of_orders from superstore group by salesperson order by no_of_orders desc;
-- finding the average order value of a salesperson
select salesperson,sum(sales) / count('order id') as AOV from superstore group by salesperson;
select salesperson,
	   sum(sales) as total_sales,
       sum(profit) as total_profit,
       sum(sales) / count('order id') as AOV,
       rank() over(order by sum(sales) desc) as sales_rank
       from superstore group by salesperson;

-- finding the growth rate of the sales person in different years
SELECT
    salesperson,
    sales_2023,
    sales_2024,
    sales_2025,
    ROUND((sales_2024 - sales_2023) / sales_2023 * 100, 2) AS growth_rate_2024,
    ROUND((sales_2025 - sales_2024) / sales_2024 * 100, 2) AS growth_rate_2025
FROM (
    SELECT
        salesperson,
        SUM(CASE WHEN `Year` = 2023 THEN sales ELSE 0 END) AS sales_2023,
        SUM(CASE WHEN `Year` = 2024 THEN sales ELSE 0 END) AS sales_2024,
        SUM(CASE WHEN `Year` = 2025 THEN sales ELSE 0 END) AS sales_2025
    FROM superstore
    GROUP BY salesperson
) AS t
ORDER BY growth_rate_2025 DESC;

-- finding the region sales by salesperson
SELECT
    region,
    salesperson,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(`Order ID`) AS no_of_orders,
    ROUND(SUM(sales) / COUNT(`Order ID`), 2) AS AOV
FROM superstore
GROUP BY region, salesperson
ORDER BY region, total_sales DESC;






